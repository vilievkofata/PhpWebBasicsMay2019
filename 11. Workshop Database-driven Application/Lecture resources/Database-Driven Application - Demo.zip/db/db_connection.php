<?php
$db = new PDO("mysql:dbname=php_web_test;host=localhost:3306", "root", "");
